#include "ecole.h"


//Fonction de lecture dans un fichier
void LectureFichierTexte(ecole_t *E, char *nomFichier);
//FONCTIONS Ecriture de fichier
void EcrireFichierTexte(const ecole_t *E, char *nomFichier);