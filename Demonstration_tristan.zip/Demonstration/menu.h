//Elias
#include "fichier.h"
// menu de premier acceuil (pas de nom d'école) propose 
// 1-la lecture d'un fichier d'école ou
// 2-Saisir d'une école entiere
void MenuAcceuil1(); 


/****************/
// Menu Classe1*/
/**************/
// menu qui permet de choisir si on veut 
/*  1- Afficher un tableau d'éléve
    2- Afficher une classe
    3- Saisir un prof
    4- Rechercher un élève dans une classe
    5- Acceuil Ecole
    6- Acceuil élève
    7- Menu des menus
*/
void MenuClasse1();


/****************/
// Menu Eleve1*/
/**************/
// menu qui permet de choisir si on veut 
/* 1- Saisir un élève\n 
   2- Afficher un élève\n
   3- Affecter un élève\n    
   4- Modifier un élève\n
   5- Rechercher un élève\n
   6- Menu principal
*/
void MenuEleve1();

void MenuEleve2();

/****************/
// Menu Ecole  */
/**************/
//Menu qui permet de choisir si on veut
/* 1-Afficher Ecole
   2- Saisir Ecole
   3- Rechercher un élève dans l'école (retourne un booleen)
   4- Rechercher si un élève est bien inscrit dans l'école sinon l'enregistrer
   5- Repartir les classes
   6- Saisir Directeur
   7- Afficher Directeur */
void MenuEcole1();


/**********************/
// Menu des 3 menus  */
/********************/
// Menu qui permet la navigation entre les menu
/* 1-Menu Elève
   2-Menu Classe
   3 - Menu École
   4 - Lire Fichier
   5 - Ecrire Fichier
   0 - Quitter
*/
void MenuGeneral();
