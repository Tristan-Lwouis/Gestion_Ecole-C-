#include "menu.h"

int main()
{
    ecole_t E1 = { //Strucure ecole_t
        .nom = "SAINT-MICHEL",
        .directeur = { //Structure directeur_t
            "Francis",
            "Cabrel"},
        { //Structure classe_t
            "CE1",
            3,
            {
                "Ken",
                "Block"
            }

        }

    };

    ecole_t monEcole = {

    .nom = "Arc-en-Ciel",
    .directeur = { "Moreau", "Sophie" },
    .nbClasse = {0, 1, 2, 0, 3, 0},
    .tabClasse = {
        {}, // NBclass 0
        { //CP en general
            { //CP1
                .nom = "CP",
                .nbrEleve = 3,
                .prof = { "Lemoine", "Paul" },
                .nbgars = 2,
                .nbfille = 1,
                .tabPersonne = {
                    {
                        .nom = "Durand",
                        .prenom = "Léo",
                        .sexe = true,
                        .dateNaissance = { .tm_year = 2016 - 1900, .tm_mon = 0, .tm_mday = 15 },
                        .numClasse = 1
                    },
                    {
                        .nom = "Martin",
                        .prenom = "Jade",
                        .sexe = false,
                        .dateNaissance = { .tm_year = 2017 - 1900, .tm_mon = 5, .tm_mday = 22 },
                        .numClasse = 1
                    },
                    {
                        .nom = "Bernard",
                        .prenom = "Noah",
                        .sexe = true,
                        .dateNaissance = { .tm_year = 2016 - 1900, .tm_mon = 10, .tm_mday = 3 },
                        .numClasse = 4
                    }
                }
            },
            {} // CP-2 vide
        },

        {}, //CE1
        {}, //CE2
        {},
        {} 
    }
};
    ecole_t E;
    ecole_t E2 = {
    .nom = "École des Petits Génies",
    .directeur = { "Lemoine", "Valérie" },
    .nbClasse = {0, 2, 1, 0, 0, 0}, // 2 classes en CP, 1 en CE1

    .tabClasse = {
        {}, //Niveau zero
        { // Niveau 1 (CP)
            { // CP-1
                .nom = "CP-1",
                .nbrEleve = 3,
                .prof = { "Durand", "Céline" },
                .nbgars = 2,
                .nbfille = 1,
                .tabPersonne = {
                    { "Dubois", "Léo", true,  {.tm_year=2016-1900, .tm_mon=2, .tm_mday=5}, 1 },
                    { "Morel", "Emma", false, {.tm_year=2017-1900, .tm_mon=9, .tm_mday=12}, 1 },
                    { "Petit", "Noah", true,   {.tm_year=2016-1900, .tm_mon=5, .tm_mday=20}, 1 }
                }
            },
            { // CP-2
                .nom = "CP-2",
                .nbrEleve = 3,
                .prof = { "Roux", "Benoît" },
                .nbgars = 1,
                .nbfille = 2,
                .tabPersonne = {
                    { "Garcia", "Lucas", true,  {.tm_year=2017-1900, .tm_mon=1, .tm_mday=18}, 1 },
                    { "Leroy", "Lina", false,   {.tm_year=2016-1900, .tm_mon=11, .tm_mday=3}, 1 },
                    { "Faure", "Zoé", false,    {.tm_year=2017-1900, .tm_mon=7, .tm_mday=25}, 1 }
                }
            }
        },
        { // Niveau 1 (CE1)
            { // CE1-1
                .nom = "CE1-1",
                .nbrEleve = 3,
                .prof = { "Marchand", "Thomas" },
                .nbgars = 2,
                .nbfille = 1,
                .tabPersonne = {
                    { "Blanc", "Adam", true,    {.tm_year=2016-1900, .tm_mon=3, .tm_mday=30}, 0 },
                    { "Meunier", "Anna", false, {.tm_year=2016-1900, .tm_mon=6, .tm_mday=14}, 0 },
                    { "Henry", "Ethan", true,   {.tm_year=2017-1900, .tm_mon=8, .tm_mday=6}, 0 }
                }
            }
        }
    }
}; 
    
//SaisirEcole(&E1);
    //AfficherEcole(&E1);
    //EcrireFichierTexte(&E2, "Ecole.txt");
    //LectureFichierTexte(&E,"Ecole.txt");
    MenuGeneral(&E2);
    //AfficherEcole(&E2);

}