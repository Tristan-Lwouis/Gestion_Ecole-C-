//TRISTAN
#include <stdio.h>
#include <stdbool.h> //Booleens
#include <time.h> //Gestion du temps
#include <stdlib.h>
#include <string.h>

#ifndef ELEVE_H
#define ELEVE_H

#define MAXCHAR 50

//----- Definition Strucutures -----

typedef struct eleve {
    char nom[MAXCHAR];
    char prenom[MAXCHAR];
    bool sexe;
    struct tm dateNaissance;
    int numClasse;

} eleve_t;

//----- Prototypes Fonctions -----
//----- Terminal ----- 

void SaisirEleve(eleve_t *A);

void AffecterEleveClasse(eleve_t *A);

void AfficherEleve(const eleve_t *A);

void ModifierEleve(eleve_t *A);

//----- Imprimer fichier -----

void ImprimerEleve(const eleve_t *A, char *nomFichier);

#endif