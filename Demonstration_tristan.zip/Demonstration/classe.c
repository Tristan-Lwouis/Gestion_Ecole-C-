#include "classe.h"

void AfficherTabEleve(const classe_t *A)
{
    for(int i=0;i<A->nbrEleve;i++)
        AfficherEleve(&A->tabPersonne[i]);
}

bool RechercheEleveClasse(const classe_t *A, const char *nom, const char *prenom, int *indicepersonne)
{   
    for(int i=0;i<A->nbrEleve;i++)
    {
        if (strcmp(nom,A->tabPersonne[i].nom)==0 && strcmp(prenom,A->tabPersonne[i].prenom)==0)
        {
            *indicepersonne=i;
            return true;
        }
        else
            return false;
    }
}

void SaisirProf(classe_t *A)
{
    printf("Saisir le nom et le prénom du professeur : ");
    scanf("%s %s",A->prof.nom,A->prof.prenom);
}

void AfficherClasse(const classe_t *A)
{
    printf("Pour la classe %s, nous avons %d élève(s) sous la direction de M.%s %s et contient %d fille et %d garçon.\n",A->nom,A->nbrEleve,A->prof.prenom,A->prof.nom,A->nbfille,A->nbgars);
    AfficherTabEleve(A);
}

//----- IMPRIMER DANS UN FICHIER .TXT ---------------------
//Penser a ajouter ces fonctions dans le .h
void ImprimerTabEleve(const classe_t *A, char *nomFichier)
{
    for(int i=0;i<A->nbrEleve;i++)
        ImprimerEleve(&A->tabPersonne[i], nomFichier); //Ajouter un pointeur
}

void ImprimerClasse(const classe_t *A, char *nomFichier)
{
    //Ouverture du fichier
    FILE *ptrfic;
    ptrfic = fopen(nomFichier, "a");
    
    if(ptrfic==NULL){
        perror("Erreur d'écriture ecriture classe");
            exit(EXIT_FAILURE);
    }

    printf(">>> Enregistrement des classes\n");
    fprintf(ptrfic,"Dans la classe il y a %d fille et %d garçon.\n",A->nbfille,A->nbgars);
    fprintf(ptrfic,"\n");
    fclose(ptrfic);
    ImprimerTabEleve(A, nomFichier);  
    
}
