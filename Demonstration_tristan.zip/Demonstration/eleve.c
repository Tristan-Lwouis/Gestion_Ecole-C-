#include "eleve.h"

void AffecterEleveClasse(eleve_t *A){ //Permet d'affecter un eleve a une classe en fonction de son age
    /*
    1- Convertir la date au format struct tm en seconde
    2- Initialiser une variable locale qui vaut la date du jour en seconde
    3- Faire la difference entre les deux pour trouver l'age de l'éleve
    4- En fonction de l'age faire un if en cascade pour modifier la valeur A.numClasse
    */
    struct tm *zero;
    int diff;
    
    time_t today = time(NULL);
    zero=localtime(&today); // convertit le time_t d'aujourd'hui en struct tm
    
    // memset(&zero,0,sizeof(struct tm)); // 6.00274 
    // today=mktime(&zero); // reconvertit en tme_t pour faire la diff
    //diff = difftime(today, DOB_Secondes);
    //diff = diff / (86400*365);

    diff = zero->tm_year - A->dateNaissance.tm_year;

    //printf("Nombre d'année d'ecart = %lf\n", diff);
    if (diff<=6)
    {
        printf("Trop jeune\n");
    }
        else if (diff==7)
        {
            A->numClasse = 1;
        }
            else if(diff == 8)
            {
                A->numClasse = 2;
            }
                else if(diff == 9)
                {
                    A->numClasse = 3;
                }
                    else if(diff == 10)
                    {
                        A->numClasse = 4;
                    }
                        else if(diff == 11)
                        {
                            A->numClasse = 5;
                        }
    else
    {
        printf("Trop vieux\n");
    }

}

void SaisirEleve(eleve_t *A){
    char temp;
    A->numClasse = 0; //Initialiser la valeur de la classe a 0.

    printf("---------- SAISIR ÉLEVE ----------\n"); //A supprimer
    printf("Quel est le prenom de l'eleve ? : ");
    scanf("%s", A->prenom);
    printf("Quel est le nom de l'eleve ? : ");
    scanf("%s", A->nom);

    // Saisie du sexe de l'éleve -------------------------------
    do { 
        printf("Quel est le sexe de %s %s ? ('H' ou 'F') : ", A->prenom, A->nom);
        scanf(" %c", &temp);
    } while (!((temp == 'H') || (temp == 'F'))); // Tant que l'utilisateur n'a pas rentrer 'G' ou 'F' il continue a redemander.
        
    switch (temp){ // En fonction de la reponse on assigne la bonne valeur a A.sexe
        case 'H':
            A->sexe = 1; //Passer le sexe a Homme
            break;
        default:
            A->sexe = 0; //Passer le sexe a Femme
            break;}

    // Saisie date de naissance de l'éleve -----------------------
    memset(&A->dateNaissance,0,sizeof(struct tm));
    printf("Quel est la date de naissance de de %s %s ? (dd/mm/yyyy)\n", A->prenom, A->nom);
    scanf("%2d/%2d/%4d", &A->dateNaissance.tm_mday, &A->dateNaissance.tm_mon, &A->dateNaissance.tm_year);
    A->dateNaissance.tm_mon -= 1;  // Les mois commencent à 0
    A->dateNaissance.tm_year -= 1900; // Les années commencent à 1900

    // Appeler la fonction AffecterEleveClasse() pour definir la classe de l'éleve
    AffecterEleveClasse(A);

}

void AfficherEleve(const eleve_t *A){
    char bufferDOB[100]; //Pour mettre la date au format texte
    char classe[100];

    printf("---------- ÉLEVE %s %s ----------\n",A->prenom, A->nom);
    printf("Nom : %s\n", A->nom);
    printf("Prenom : %s\n", A->prenom);
    printf("Sexe : %s\n",(A->sexe == true ? "Homme" : "Femme")); //Fonction ternaire pour afficher une chaine de caractere en fonction de la valeur de A.sexe

    strftime(bufferDOB, 100, "%d-%m-%Y", &A->dateNaissance); //Convertir une struct tm en chaîne de caractères
    printf("Date de naissance : %s\n",bufferDOB);
    switch (A->numClasse){ //Afficher la chaine de caractere "CE1" en fonction de i
        case 1:
            strcpy(classe,"CP");
            break;
        case 2:
            strcpy(classe,"CE1");
            break;
        case 3:
            strcpy(classe,"CE2");
            break;
        case 4:
            strcpy(classe,"CM1");
            break;
        case 5:
            strcpy(classe,"CM2");
            break;
    }
    printf("Classe de l'eleve %s\n", classe);
}       

void ModifierEleve(eleve_t *A){
        char reponse;
        char temp;
        char bufferDOB[100];

        printf("---------- MODIFIER ÉLEVE %s %s -----------\n",A->prenom, A->nom);

        printf("-------------------------------------------\n");
        printf("| Que voulez vous modifier ? -------------|\n");
        printf("| -1 : Prenom-----------------------------|\n");
        printf("| -2 : Nom--------------------------------|\n");
        printf("| -3 : Sexe-------------------------------|\n");
        printf("| -4 : Date de naissance------------------|\n");
        printf("-------------------------------------------\n");

        scanf(" %c", &reponse);

        switch (reponse)
        {
        case '1':
            printf("Vous avez choisis de modifier le prenom \"%s\", par quoi voulez vous le modifier ?\n", A->prenom);
            scanf("%s", A->prenom);
            break;
        
        case '2':
            printf("Vous avez choisis de modifier le nom \"%s\", par quoi voulez vous le modifier ?\n", A->nom);
            scanf("%s", A->nom);
            break;

        case '3':
            printf("Vous avez choisis de modifier le sexe \"%s\", par quoi voulez vous le modifier ?\n", (A->sexe == true ? "Homme" : "Femme"));
            printf("\n");
            do { 
                printf("Quel est le sexe de %s %s ? ('H' ou 'F') : ", A->prenom, A->nom);
                scanf(" %c", &temp);
            } while (!((temp == 'H') || (temp == 'F'))); // Tant que l'utilisateur n'a pas rentrer 'G' ou 'F' il continue a redemander.
                
            switch (temp){ // En fonction de la reponse on assigne la bonne valeur a A.sexe
                case 'H':
                    A->sexe = 1; //Passer le sexe a Homme
                    break;
                default:
                    A->sexe = 0; //Passer le sexe a Femme
                    break;}
                    break;

        case '4':
            printf("Vous avez choisis de modifier la date de naissance ");
            strftime(bufferDOB, 100, "%d-%m-%Y", &A->dateNaissance); //Convertir une struct tm en chaîne de caractères
            printf("Date de naissance : %s\n",bufferDOB);
            printf(" par quoi voulez vous la modifier ? (dd/mm/yyyy) \n");

            scanf("%2d/%2d/%4d", &A->dateNaissance.tm_mday, &A->dateNaissance.tm_mon, &A->dateNaissance.tm_year);
            A->dateNaissance.tm_mon -= 1;  // Les mois commencent à 0
            A->dateNaissance.tm_year -= 1900; // Les années commencent à 1900

            strftime(bufferDOB, 100, "%d-%m-%Y", &A->dateNaissance); //Convertir une struct tm en chaîne de caractères
            printf("NOUVELLE Date de naissance : %s\n",bufferDOB);

            break;
        
        default:
            printf("Veuillez choisir un chiffre entre 1 et 4 ou appuyer sur 'q' pour quitter\n");
            break;
        }
}

// ----- IMPRIMER ELEVE -----

void ImprimerEleve(const eleve_t *A, char *nomFichier){
    //Ouverture du fichier
    FILE *ptrfic;
    ptrfic = fopen(nomFichier, "a");
    
    if(ptrfic==NULL){
        perror("Erreur d'écriture de l'éleve");
            exit(EXIT_FAILURE);
    }
    char bufferDOB[100]; //Pour mettre la date au format texte
    char classe[100];

    fprintf(ptrfic,"---------- ÉLEVE %s %s ----------\n",A->prenom, A->nom);
    fprintf(ptrfic,"Nom : %s\n", A->nom);
    fprintf(ptrfic,"Prenom : %s\n", A->prenom);
    fprintf(ptrfic,"Sexe : %s\n",(A->sexe == true ? "Homme" : "Femme")); //Fonction ternaire pour afficher une chaine de caractere en fonction de la valeur de A.sexe

    strftime(bufferDOB, 100, "%d-%m-%Y", &A->dateNaissance); //Convertir une struct tm en chaîne de caractères
    fprintf(ptrfic,"Date de naissance : %s\n",bufferDOB);
    switch (A->numClasse){ //Afficher la chaine de caractere "CE1" en fonction de i
        case 1:
            strcpy(classe,"CP");
            break;
        case 2:
            strcpy(classe,"CE1");
            break;
        case 3:
            strcpy(classe,"CE2");
            break;
        case 4:
            strcpy(classe,"CM1");
            break;
        case 5:
            strcpy(classe,"CM2");
            break;
    }
    fprintf(ptrfic,"\n");
    fclose(ptrfic);
}